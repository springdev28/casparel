import { useState, useRef, useEffect } from "react";
import { useLocation, useSearch as useRouteSearch, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import {
  Search,
  Plus,
  LogIn,
  Globe,
  ExternalLink,
  Loader2,
  BookOpen,
  Sparkles,
  X,
  Wand2,
  Trash2,
  GraduationCap,
  FileText,
  Video,
  FileType2,
  Headphones,
  MousePointerClick,
  ImageIcon,
  ShieldCheck,
  CircleHelp,
  RefreshCw,
} from "lucide-react";
import { Button } from "@workspace/edu-ds/components/ui/button";
import { Input } from "@workspace/edu-ds/components/ui/input";
import { Label } from "@workspace/edu-ds/components/ui/label";
import {
  Card,
  CardContent,
  CardFooter,
  CardHeader,
  CardTitle,
  CardDescription,
} from "@workspace/edu-ds/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@workspace/edu-ds/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@workspace/edu-ds/components/ui/select";
import { Skeleton } from "@workspace/edu-ds/components/ui/skeleton";
import { Textarea } from "@workspace/edu-ds/components/ui/textarea";
import { toast } from "@workspace/edu-ds/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import {
  useListResources,
  useCreateResource,
  useDeleteResource,
  useGetMe,
  useDiscoverResources,
  useListLearningGoals,
  usePrefetchResourceMetadata,
  useListClasses,
  useAssignResourceToClass,
  getDiscoverResourcesQueryKey,
  getListResourcesQueryKey,
  getGetMeQueryKey,
  getGetResourceRecommendationsQueryKey,
  getGetDashboardSummaryQueryKey,
  getGetClassResourcesListQueryKey,
  getListClassesQueryKey,
  getListLearningGoalsQueryKey,
  ListResourcesFormat,
  ListResourcesSortBy,
  ResourceInputFormat,
  DiscoverResourcesFormat,
  DiscoverResourcesLanguage,
  DiscoverResourcesResultType,
  UserRole,
  type DiscoveredResource,
} from "@workspace/api-client-react";
import { StarRating } from "../components/StarRating";
import { AUTH_LANGUAGES, useAuthLanguage } from "../lib/auth-locale";
import {
  addSearchHistory,
  deleteSearchHistory,
  getSearchHistory,
  type SearchHistoryItem,
} from "../lib/searchHistory";

const FORMAT_OPTIONS = Object.values(ListResourcesFormat);
const DAILY_SOURCE_RECOMMENDATION_LIMIT = 3;

function sourceRecommendationUsageKey(userId?: number) {
  const date = new Date().toLocaleDateString("en-CA");
  return `schoolar_source_recommendations:${userId ?? "guest"}:${date}`;
}

function getSourceRecommendationUsage(userId?: number) {
  const value = Number(
    localStorage.getItem(sourceRecommendationUsageKey(userId)) ?? "0",
  );
  return Number.isFinite(value) && value > 0 ? value : 0;
}
const SEARCH_LANGUAGE_OPTIONS = [
  { code: DiscoverResourcesLanguage.any, label: "Any language" },
  ...AUTH_LANGUAGES,
];
type SearchLanguage = (typeof SEARCH_LANGUAGE_OPTIONS)[number]["code"];

const FORMAT_COLORS: Record<string, string> = {
  article: "bg-blue-100 text-blue-700",
  video: "bg-red-100 text-red-700",
  pdf: "bg-orange-100 text-orange-700",

  podcast: "bg-purple-100 text-purple-700",
  interactive: "bg-emerald-100 text-emerald-700",
  other: "bg-gray-100 text-gray-700",
};
function ProvenanceBadge({ resource }: { resource: DiscoveredResource }) {
  if (!resource.provenanceLevel) return null;
  const labels = {
    institutional: "Institutional source",
    established: "Established platform",
    independent: "Independent source",
    unknown: "Unknown source",
  } as const;
  const colors = {
    institutional: "border-emerald-500/30 bg-emerald-500/10 text-emerald-700",
    established: "border-blue-500/30 bg-blue-500/10 text-blue-700",
    independent: "border-amber-500/30 bg-amber-500/10 text-amber-700",
    unknown: "border-muted bg-muted text-muted-foreground",
  } as const;
  const level = resource.provenanceLevel;
  return (
    <details className="group mt-2 text-xs">
      <summary
        className={`inline-flex cursor-pointer list-none items-center gap-1.5 rounded-full border px-2 py-1 font-medium ${colors[level]}`}
      >
        <ShieldCheck className="size-3.5" />
        {labels[level]}
        {resource.linkChecked && (
          <span aria-label="Link checked">· link checked</span>
        )}
        <CircleHelp className="size-3 opacity-60" />
      </summary>
      <div className="mt-2 rounded-lg border bg-muted/40 p-2.5 text-muted-foreground">
        <p className="mb-1 font-medium text-foreground">Why this label?</p>
        <ul className="space-y-1">
          {resource.provenanceSignals?.map((signal) => (
            <li key={signal}>• {signal}</li>
          ))}
        </ul>
        <p className="mt-2 text-[11px]">
          Publisher provenance and link availability do not verify every claim
          in the content.
        </p>
      </div>
    </details>
  );
}

function getYouTubeId(url: string): string | null {
  try {
    const u = new URL(url);
    if (u.hostname === "youtu.be") return u.pathname.slice(1).split("?")[0];
    if (u.hostname.includes("youtube.com")) {
      const v = u.searchParams.get("v");
      if (v) return v;
      const m = u.pathname.match(/\/(?:embed|shorts)\/([^/?]+)/);
      if (m) return m[1];
    }
    return null;
  } catch {
    return null;
  }
}

function isVimeoUrl(url: string): boolean {
  try {
    return new URL(url).hostname.includes("vimeo.com");
  } catch {
    return false;
  }
}

function isLoomUrl(url: string): boolean {
  try {
    return new URL(url).hostname.includes("loom.com");
  } catch {
    return false;
  }
}

/** Server-side OEmbed proxy — avoids CORS and third-party rate-limit failures. */
function useOembedThumbnail(url: string, enabled: boolean) {
  return useQuery<string | null>({
    queryKey: ["oembed-thumbnail", url],
    queryFn: async () => {
      const res = await fetch(
        `/api/resources/oembed?url=${encodeURIComponent(url)}`,
      );
      if (!res.ok) return null;
      const data = (await res.json()) as { thumbnailUrl: string | null };
      return data.thumbnailUrl ?? null;
    },
    enabled,
    staleTime: 1000 * 60 * 60, // 1 hour — thumbnail URLs don't change
    retry: false,
  });
}

function FormatBadge({ format }: { format: string }) {
  return (
    <span
      className={`text-xs font-medium px-2 py-0.5 rounded-full shrink-0 capitalize ${FORMAT_COLORS[format] ?? FORMAT_COLORS.other}`}
    >
      {format}
    </span>
  );
}

const FORMAT_PREVIEW_STYLES: Record<string, string> = {
  article: "from-blue-100 via-sky-50 to-white text-blue-700",
  video: "from-red-100 via-rose-50 to-white text-red-700",
  pdf: "from-orange-100 via-amber-50 to-white text-orange-700",
  podcast: "from-purple-100 via-violet-50 to-white text-purple-700",
  interactive: "from-emerald-100 via-teal-50 to-white text-emerald-700",
  other: "from-slate-100 via-gray-50 to-white text-slate-700",
};

function FormatPreview({
  url,
  format,
  title,
}: {
  url: string;
  format: string;
  title: string;
}) {
  let hostname = "Learning resource";
  try {
    hostname = new URL(url).hostname.replace(/^www\./, "");
  } catch {
    /* keep fallback */
  }

  const iconClass = "size-9";
  const icon =
    format === "article" ? (
      <FileText className={iconClass} />
    ) : format === "video" ? (
      <Video className={iconClass} />
    ) : format === "pdf" ? (
      <FileType2 className={iconClass} />
    ) : format === "podcast" ? (
      <Headphones className={iconClass} />
    ) : format === "interactive" ? (
      <MousePointerClick className={iconClass} />
    ) : (
      <ImageIcon className={iconClass} />
    );

  return (
    <div
      className={`w-full h-36 bg-gradient-to-br ${FORMAT_PREVIEW_STYLES[format] ?? FORMAT_PREVIEW_STYLES.other} flex flex-col items-center justify-center gap-2 px-5 text-center`}
      role="img"
      aria-label={`${format} preview for ${title}`}
    >
      {icon}
      <span className="max-w-full truncate text-xs font-semibold">
        {hostname}
      </span>
      <span className="text-[10px] font-medium uppercase tracking-widest opacity-70">
        {format}
      </span>
    </div>
  );
}

// ── Shared resource card (library) ────────────────────────────────────────────
function LibraryCard({
  resource,
  onClick,
  onRemove,
  onAssign,
}: {
  resource: {
    id: number;
    title: string;
    url: string;
    format: string;
    subject: string;
    gradeLevel: string;
    description?: string | null;
    avgRating: number;
    reviewCount: number;
    thumbnailUrl?: string | null;
  };
  onClick: () => void;
  onRemove?: () => void;
  onAssign?: () => void;
}) {
  const [failedThumb, setFailedThumb] = useState<string | null>(null);
  const ytId = getYouTubeId(resource.url);
  const needsOembed =
    !ytId && (isVimeoUrl(resource.url) || isLoomUrl(resource.url));
  const { data: oembedThumb } = useOembedThumbnail(resource.url, needsOembed);
  const thumb = ytId
    ? `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`
    : (oembedThumb ?? resource.thumbnailUrl ?? null);
  const showImg = !!thumb && thumb !== failedThumb;
  return (
    <Card
      className="cursor-pointer hover:shadow-md transition-shadow overflow-hidden"
      onClick={onClick}
      data-testid="resource-card"
    >
      {showImg && (
        <div className="w-full h-36 overflow-hidden bg-black">
          <img
            src={thumb}
            alt={resource.title}
            className="w-full h-full object-cover"
            loading="lazy"
            onError={() => setFailedThumb(thumb)}
          />
        </div>
      )}
      {!showImg && (
        <FormatPreview
          url={resource.url}
          format={resource.format}
          title={resource.title}
        />
      )}
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-base line-clamp-2">
            {resource.title}
          </CardTitle>
          <FormatBadge format={resource.format} />
        </div>
        <CardDescription className="text-xs">
          {resource.subject} · {resource.gradeLevel}
        </CardDescription>
      </CardHeader>
      {resource.description && (
        <CardContent className="pb-2">
          <p className="text-sm text-muted-foreground line-clamp-2">
            {resource.description}
          </p>
        </CardContent>
      )}
      <CardFooter className="flex items-center justify-between pt-2">
        <StarRating value={resource.avgRating} size="sm" />
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">
            {resource.reviewCount} review{resource.reviewCount !== 1 ? "s" : ""}
          </span>
          {onAssign && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onAssign();
              }}
              className="text-muted-foreground hover:text-primary transition-colors"
              title="Assign to class"
            >
              <GraduationCap size={13} />
            </button>
          )}
          {onRemove && (
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                onRemove();
              }}
              className="text-muted-foreground hover:text-destructive transition-colors"
              title="Remove from library"
            >
              <Trash2 size={13} />
            </button>
          )}
        </div>
      </CardFooter>
    </Card>
  );
}

// ── Web result card ───────────────────────────────────────────────────────────
function WebCard({
  resource,
  onAdd,
  adding,
}: {
  resource: DiscoveredResource;
  onAdd: (r: DiscoveredResource) => void;
  adding: boolean;
}) {
  const [failedThumb, setFailedThumb] = useState<string | null>(null);
  const ytId = getYouTubeId(resource.url);
  const needsOembed =
    !ytId && (isVimeoUrl(resource.url) || isLoomUrl(resource.url));
  const { data: oembedThumb } = useOembedThumbnail(resource.url, needsOembed);
  const thumb = ytId
    ? `https://img.youtube.com/vi/${ytId}/hqdefault.jpg`
    : (oembedThumb ?? resource.thumbnailUrl ?? null);
  const showImg = !!thumb && thumb !== failedThumb;
  return (
    <Card className="flex flex-col overflow-hidden">
      {showImg && (
        <div className="w-full h-36 overflow-hidden bg-black shrink-0">
          <img
            src={thumb}
            alt={resource.title}
            className="w-full h-full object-cover"
            loading="lazy"
            onError={() => setFailedThumb(thumb)}
          />
        </div>
      )}
      {!showImg && (
        <FormatPreview
          url={resource.url}
          format={resource.format}
          title={resource.title}
        />
      )}
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-base line-clamp-2 leading-snug">
            {resource.title}
          </CardTitle>
          <FormatBadge format={resource.format} />
        </div>
        <CardDescription className="text-xs">
          {resource.source}
          {resource.subject ? ` · ${resource.subject}` : ""}
          {resource.gradeLevel ? ` · ${resource.gradeLevel}` : ""}
          <ProvenanceBadge resource={resource} />
        </CardDescription>
      </CardHeader>
      <CardContent className="pb-2 flex-1">
        <p className="text-sm text-muted-foreground line-clamp-3">
          {resource.description}
        </p>
      </CardContent>
      <CardFooter className="gap-2 pt-2 flex-wrap">
        <Button size="sm" variant="outline" asChild className="flex-1">
          <a href={resource.url} target="_blank" rel="noopener noreferrer">
            <ExternalLink size={12} className="mr-1.5" /> Open
          </a>
        </Button>
        <Button
          size="sm"
          className="flex-1"
          disabled={adding}
          onClick={() => onAdd(resource)}
        >
          {adding ? (
            <>
              <Loader2 size={12} className="mr-1.5 animate-spin" /> Adding…
            </>
          ) : (
            <>
              <Plus size={12} className="mr-1.5" /> Save
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}

function SourceCard({
  resource,
  onSave,
  saving,
}: {
  resource: DiscoveredResource;
  onSave: (resource: DiscoveredResource) => void;
  saving: boolean;
}) {
  let hostname = resource.source;
  try {
    hostname = new URL(resource.url).hostname.replace(/^www\./, "");
  } catch {
    /* keep source */
  }
  const isChannel = /youtube\.com|vimeo\.com|podcasts?\.|tiktok\.com/i.test(
    resource.url,
  );
  return (
    <Card className="flex h-full flex-col border-primary/15 bg-gradient-to-br from-card to-primary/5">
      <CardHeader className="pb-3">
        <div className="mb-3 flex size-11 items-center justify-center rounded-xl bg-primary/10 text-primary">
          {isChannel ? <Video size={22} /> : <Globe size={22} />}
        </div>
        <CardTitle className="text-lg leading-snug">{resource.title}</CardTitle>
        <CardDescription className="truncate">{hostname}</CardDescription>
        <ProvenanceBadge resource={resource} />
      </CardHeader>
      <CardContent className="flex-1">
        <p className="line-clamp-3 text-sm text-muted-foreground">
          {resource.description}
        </p>
        <div className="mt-3 flex flex-wrap gap-1.5">
          <span className="rounded-full bg-primary/10 px-2 py-1 text-xs font-medium text-primary">
            {isChannel ? "Channel" : "Website"}
          </span>
          {resource.subject && (
            <span className="rounded-full bg-muted px-2 py-1 text-xs">
              {resource.subject}
            </span>
          )}
        </div>
      </CardContent>
      <CardFooter className="gap-2">
        <Button asChild variant="outline" className="flex-1">
          <a href={resource.url} target="_blank" rel="noopener noreferrer">
            <ExternalLink size={14} className="mr-2" /> Visit{" "}
            {isChannel ? "channel" : "website"}
          </a>
        </Button>
        <Button
          className="flex-1"
          disabled={saving}
          onClick={() => onSave(resource)}
          data-testid="save-recommended-source"
        >
          {saving ? (
            <Loader2 size={14} className="mr-2 animate-spin" />
          ) : (
            <Plus size={14} className="mr-2" />
          )}
          {saving ? "Saving…" : "Save source"}
        </Button>
      </CardFooter>
    </Card>
  );
}

// ── Skeleton grid ─────────────────────────────────────────────────────────────────────────────────────────────────────────────────────────
function CardSkeletons({ count = 6 }: { count?: number }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {Array.from({ length: count }).map((_, i) => (
        <Card key={i}>
          <CardHeader>
            <Skeleton className="h-5 w-3/4" />
            <Skeleton className="h-4 w-1/2 mt-1" />
          </CardHeader>
          <CardContent>
            <Skeleton className="h-14 w-full" />
          </CardContent>
          <CardFooter>
            <Skeleton className="h-4 w-24" />
          </CardFooter>
        </Card>
      ))}
    </div>
  );
}

// ── Main ──────────────────────────────────────────────────────────────────────

export default function ResourcesPage() {
  const [, setLocation] = useLocation();
  const { language: interfaceLanguage } = useAuthLanguage();
  const routeSearch = useRouteSearch();
  const queryClient = useQueryClient();
  const inputRef = useRef<HTMLInputElement>(null);

  const [inputValue, setInputValue] = useState("");
  const [activeQuery, setActiveQuery] = useState("");
  const [formatFilter, setFormatFilter] = useState("");
  const [subjectFilter, setSubjectFilter] = useState("");
  const [gradeLevelFilter, setGradeLevelFilter] = useState("");
  const [searchLanguage, setSearchLanguage] =
    useState<SearchLanguage>(interfaceLanguage);
  const [resultTypeFilter, setResultTypeFilter] =
    useState<DiscoverResourcesResultType>(DiscoverResourcesResultType.content);
  const [sortByFilter, setSortByFilter] = useState<ListResourcesSortBy | "">(
    "",
  );
  const [minRatingFilter, setMinRatingFilter] = useState<number | "">("");
  const [libraryLimit, setLibraryLimit] = useState(12);
  const [webPage, setWebPage] = useState(1);
  const [allWebResults, setAllWebResults] = useState<DiscoveredResource[]>([]);
  const [hiddenSourceUrls, setHiddenSourceUrls] = useState<string[]>([]);
  const [sourceRefreshes, setSourceRefreshes] = useState(0);
  const [searchHistory, setSearchHistory] = useState<SearchHistoryItem[]>([]);

  useEffect(() => {
    const params = new URLSearchParams(routeSearch);
    const goal = params.get("goal");
    const subject = params.get("subject");
    const mode = params.get("mode");
    if (goal) {
      setInputValue(goal);
      setActiveQuery(goal);
      setLibraryLimit(12);
    }
    if (subject) setSubjectFilter(subject);
    if (mode === "source") setResultTypeFilter(DiscoverResourcesResultType.source);
  }, [routeSearch]);

  const isSearching = activeQuery.trim().length > 0;
  const isSourceMode = resultTypeFilter === DiscoverResourcesResultType.source;

  // Auth
  const { data: me } = useGetMe({
    query: { retry: false, queryKey: getGetMeQueryKey() },
  });
  const isLoggedIn = !!me;
  const isAdmin = me?.role === "admin";

  useEffect(() => {
    setSourceRefreshes(getSourceRecommendationUsage(me?.id));
  }, [me?.id]);

  useEffect(() => {
    setSearchHistory(getSearchHistory(me?.id));
  }, [me?.id]);

  const { data: learningGoals } = useListLearningGoals({
    query: { enabled: isLoggedIn, queryKey: getListLearningGoalsQueryKey() },
  });
  const personalisedSourceQuery = [
    ...(me?.subjects ?? []),
    ...(learningGoals ?? [])
      .filter((goal) => goal.status === "active")
      .flatMap((goal) => [goal.title, goal.subject]),
  ]
    .map((term) => term.trim())
    .filter(Boolean)
    .filter((term, index, all) => all.indexOf(term) === index)
    .slice(0, 8)
    .join(" ") || "high-quality educational sources for lifelong learning";
  const personalisedDiscoverParams = {
    q: personalisedSourceQuery,
    resultType: DiscoverResourcesResultType.source,
    page: 1,
  };
  const { data: personalisedSources, isFetching: personalisedSourcesLoading } =
    useDiscoverResources(personalisedDiscoverParams, {
      query: {
        enabled: !isSearching,
        queryKey: ["personalised-internet-sources", me?.id ?? "guest", personalisedSourceQuery],
        staleTime: 300_000,
        retry: false,
      },
    });

  // Library search results (shown when searching)
  const libraryParams = {
    ...(activeQuery ? { q: activeQuery } : {}),
    ...(formatFilter && formatFilter !== "all"
      ? { format: formatFilter as ListResourcesFormat }
      : {}),
    ...(subjectFilter.trim() ? { subject: subjectFilter.trim() } : {}),
    ...(gradeLevelFilter ? { gradeLevel: gradeLevelFilter } : {}),
    ...(sortByFilter ? { sortBy: sortByFilter } : {}),
    ...(minRatingFilter ? { minRating: minRatingFilter as number } : {}),
    limit: libraryLimit,
    offset: 0,
  };
  const { data: libraryResults, isLoading: libraryLoading } = useListResources(
    libraryParams,
    {
      query: {
        enabled: isSearching && !isSourceMode,
        queryKey: getListResourcesQueryKey(libraryParams),
      },
    },
  );

  // Load the catalogue to identify this user's existing library URLs even
  // while source-only mode hides the library results panel.
  const libraryCatalogParams = { limit: 50, offset: 0 };
  const { data: libraryCatalog } = useListResources(libraryCatalogParams, {
    query: {
      enabled: isLoggedIn,
      queryKey: getListResourcesQueryKey(libraryCatalogParams),
    },
  });
  const savedLibraryUrls = new Set(
    (libraryCatalog ?? [])
      .filter((resource) => resource.submittedById === me?.id)
      .map((resource) => resource.url),
  );

  // Web discover (shown when searching) — accumulate across pages
  const discoverParams = {
    q: activeQuery,
    ...(resultTypeFilter === DiscoverResourcesResultType.content &&
    formatFilter &&
    formatFilter !== "all"
      ? { format: formatFilter as DiscoverResourcesFormat }
      : {}),
    ...(subjectFilter.trim() ? { subject: subjectFilter.trim() } : {}),
    ...(resultTypeFilter === DiscoverResourcesResultType.content &&
    gradeLevelFilter
      ? { gradeLevel: gradeLevelFilter }
      : {}),
    language: searchLanguage,
    page: webPage,
    resultType: resultTypeFilter,
  };
  const {
    data: webResults,
    isFetching: webLoading,
    isError: webError,
    error: webErrorObj,
  } = useDiscoverResources(discoverParams, {
    query: {
      enabled: isSearching,
      staleTime: 1000 * 60 * 5,
      queryKey: getDiscoverResourcesQueryKey(discoverParams),
      retry: false,
    },
  });

  // Detect 429 rate-limit responses from the discover endpoint.
  // The generated client throws ApiError with .status (HTTP code) and .data (parsed body).
  const webRateLimited =
    webError && (webErrorObj as { status?: number } | null)?.status === 429;
  const webRateLimitRetryAfter: number = webRateLimited
    ? ((webErrorObj as { data?: { retryAfter?: number } } | null)?.data
        ?.retryAfter ?? 60)
    : 0;

  // Reset accumulated results when query changes; append on page increment
  useEffect(() => {
    setWebPage(1);
    setAllWebResults([]);
    setHiddenSourceUrls([]);
  }, [activeQuery]);

  // Reset accumulated results when any filter changes
  useEffect(() => {
    setWebPage(1);
    setAllWebResults([]);
  }, [
    formatFilter,
    subjectFilter,
    gradeLevelFilter,
    sortByFilter,
    minRatingFilter,
    resultTypeFilter,
    searchLanguage,
  ]);

  useEffect(() => {
    if (!webResults || webResults.length === 0) return;
    setAllWebResults((prev) =>
      webPage === 1 ? webResults : [...prev, ...webResults],
    );
  }, [webResults, webPage]);

  const isTeacher = (me?.activeRole ?? me?.role) === UserRole.teacher;

  // Classes for "Assign to class" teacher flow
  const { data: classes } = useListClasses({
    query: { enabled: isTeacher, queryKey: getListClassesQueryKey() },
  });
  const assignResource = useAssignResourceToClass();
  const [assignTarget, setAssignTarget] = useState<{
    id: number;
    title: string;
  } | null>(null);
  const [assignClassId, setAssignClassId] = useState("");

  async function handleAssign() {
    if (!assignTarget || !assignClassId) return;
    try {
      await assignResource.mutateAsync({
        id: Number(assignClassId),
        data: { resourceId: assignTarget.id },
      });
      queryClient.invalidateQueries({
        queryKey: getGetClassResourcesListQueryKey(Number(assignClassId)),
      });
      toast({
        title: "Assigned!",
        description: `"${assignTarget.title}" added to the class resource list.`,
      });
      setAssignTarget(null);
      setAssignClassId("");
    } catch {
      toast({
        title: "Error",
        description: "Could not assign the resource.",
        variant: "destructive",
      });
    }
  }

  const createResource = useCreateResource();
  const deleteResource = useDeleteResource();
  const prefetchMetadata = usePrefetchResourceMetadata();

  async function handleRemoveCard(resourceId: number, title: string) {
    try {
      await deleteResource.mutateAsync({ id: resourceId });
      queryClient.invalidateQueries({ queryKey: getListResourcesQueryKey() });
      queryClient.invalidateQueries({
        queryKey: getGetResourceRecommendationsQueryKey(),
      });
      queryClient.invalidateQueries({
        queryKey: getGetDashboardSummaryQueryKey(),
      });
      toast({
        title: "Removed",
        description: `"${title}" has been removed from the library.`,
      });
    } catch {
      toast({
        title: "Error",
        description: "Could not remove the resource.",
        variant: "destructive",
      });
    }
  }
  const [addingUrl, setAddingUrl] = useState<string | null>(null);

  // Submit form
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newUrl, setNewUrl] = useState("");
  const [newDesc, setNewDesc] = useState("");
  const [newFormat, setNewFormat] = useState<ResourceInputFormat>(
    ResourceInputFormat.article,
  );
  const [newSubject, setNewSubject] = useState("");
  const [newGrade, setNewGrade] = useState("");
  const [prefetching, setPrefetching] = useState(false);
  const [prefetchedThumbnailUrl, setPrefetchedThumbnailUrl] = useState<
    string | null
  >(null);
  // Track which URL is currently being fetched so stale responses don't clobber newer edits
  const prefetchingUrlRef = useRef<string>("");

  async function handleUrlBlur() {
    const url = newUrl.trim();
    if (!url) return;
    try {
      const u = new URL(url);
      if (u.protocol !== "http:" && u.protocol !== "https:") return;
    } catch {
      return;
    } // not a valid URL yet — skip
    // Don't prefetch if title is already filled (user typed it themselves)
    if (newTitle.trim()) return;

    prefetchingUrlRef.current = url;
    setPrefetching(true);
    try {
      const meta = await prefetchMetadata.mutateAsync({ data: { url } });
      // Only apply if the URL hasn't changed since we fired this request
      if (prefetchingUrlRef.current !== url) return;
      // Use functional updaters so we read the *current* state, not the closure-captured one.
      // This prevents a stale response from overwriting text the user typed while waiting.
      if (meta.title) setNewTitle((cur) => (cur.trim() ? cur : meta.title));
      if (meta.description)
        setNewDesc((cur) => (cur.trim() ? cur : meta.description));
      if (meta.format)
        setNewFormat((cur) =>
          cur !== ResourceInputFormat.article
            ? cur
            : (meta.format as ResourceInputFormat),
        );
      setPrefetchedThumbnailUrl(meta.thumbnailUrl ?? null);
    } catch {
      // silently ignore — user can fill in manually
    } finally {
      if (prefetchingUrlRef.current === url) setPrefetching(false);
    }
  }

  function clearSearch() {
    setInputValue("");
    setActiveQuery("");
    inputRef.current?.focus();
  }

  function handleSearchSubmit(e: React.FormEvent) {
    e.preventDefault();
    const q = inputValue.trim();
    if (q) {
      setActiveQuery(q);
      setLibraryLimit(12); // reset pagination on new search
      if (me?.id) setSearchHistory(addSearchHistory(me.id, q));
    }
  }

  function resetForm() {
    setNewTitle("");
    setNewUrl("");
    setNewDesc("");
    setNewFormat(ResourceInputFormat.article);
    setNewSubject("");
    setNewGrade("");
    setPrefetchedThumbnailUrl(null);
  }

  async function handleCreate(e: React.FormEvent) {
    e.preventDefault();
    try {
      await createResource.mutateAsync({
        data: {
          title: newTitle,
          url: newUrl,
          description: newDesc || undefined,
          format: newFormat,
          subject: newSubject,
          gradeLevel: newGrade,
          thumbnailUrl: prefetchedThumbnailUrl ?? undefined,
        },
      });
      queryClient.invalidateQueries({ queryKey: getListResourcesQueryKey() });
      queryClient.invalidateQueries({
        queryKey: getGetResourceRecommendationsQueryKey(),
      });
      queryClient.invalidateQueries({
        queryKey: getGetDashboardSummaryQueryKey(),
      });
      toast({
        title: "Resource submitted!",
        description: `"${newTitle}" has been added.`,
      });
      resetForm();
      setDialogOpen(false);
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed",
        variant: "destructive",
      });
    }
  }

  async function handleAddWeb(resource: DiscoveredResource): Promise<boolean> {
    if (!isLoggedIn) {
      setLocation("/auth/login");
      return false;
    }
    setAddingUrl(resource.url);
    try {
      await createResource.mutateAsync({
        data: {
          title: resource.title,
          url: resource.url,
          description: resource.description,
          format: resource.format as ResourceInputFormat,
          subject: resource.subject ?? "General",
          gradeLevel: resource.gradeLevel ?? "All grades",
          thumbnailUrl: resource.thumbnailUrl ?? undefined,
        },
      });
      queryClient.invalidateQueries({ queryKey: getListResourcesQueryKey() });
      queryClient.invalidateQueries({
        queryKey: getGetResourceRecommendationsQueryKey(),
      });
      queryClient.invalidateQueries({
        queryKey: getGetDashboardSummaryQueryKey(),
      });
      toast({
        title: "Saved to library!",
        description: `"${resource.title}" added.`,
      });
      return true;
    } catch (err) {
      toast({
        title: "Error",
        description: err instanceof Error ? err.message : "Failed",
        variant: "destructive",
      });
      return false;
    } finally {
      setAddingUrl(null);
    }
  }

  async function handleSaveSource(resource: DiscoveredResource) {
    const saved = await handleAddWeb(resource);
    if (saved) {
      // Advance immediately; the invalidated library query also ensures this
      // URL remains excluded if the search results are rebuilt.
      setHiddenSourceUrls((urls) => [...new Set([...urls, resource.url])]);
    }
  }

  function recommendAnotherSource(sourcePool: DiscoveredResource[] = allWebResults) {
    if (!isAdmin && sourceRefreshes >= DAILY_SOURCE_RECOMMENDATION_LIMIT) return;
    const visibleSource = sourcePool.find(
      (resource) =>
        !hiddenSourceUrls.includes(resource.url) &&
        !savedLibraryUrls.has(resource.url),
    );
    if (!visibleSource) return;
    setHiddenSourceUrls((urls) => [...new Set([...urls, visibleSource.url])]);
    if (isAdmin) return;
    setSourceRefreshes((count) => {
      const next = Math.min(
        count + 1,
        DAILY_SOURCE_RECOMMENDATION_LIMIT,
      );
      localStorage.setItem(
        sourceRecommendationUsageKey(me?.id),
        String(next),
      );
      return next;
    });
  }

  return (
    <div className="p-6 max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Resources</h1>
          <p className="text-muted-foreground text-sm mt-1">
            {isSearching
              ? `Showing library results and web results for "${activeQuery}"`
              : isLoggedIn
                ? "Your personalised library — based on what you've been learning"
                : "Top-rated resources to get you started"}
          </p>
        </div>
        {isLoggedIn ? (
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button data-testid="submit-resource-button">
                <Plus size={16} className="mr-1.5" /> Submit Resource
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-lg">
              <DialogHeader>
                <DialogTitle>Submit a Resource</DialogTitle>
                <DialogDescription>
                  Share a learning resource with the community
                </DialogDescription>
              </DialogHeader>
              <form onSubmit={handleCreate} className="space-y-4">
                <div className="space-y-1.5">
                  <Label htmlFor="res-title">Title</Label>
                  <Input
                    id="res-title"
                    value={newTitle}
                    onChange={(e) => setNewTitle(e.target.value)}
                    required
                    data-testid="resource-title-input"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label
                    htmlFor="res-url"
                    className="flex items-center gap-1.5"
                  >
                    URL
                    {prefetching && (
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Loader2 size={10} className="animate-spin" />{" "}
                        auto-filling…
                      </span>
                    )}
                    {!prefetching && newTitle && newUrl && (
                      <span className="text-xs text-muted-foreground flex items-center gap-1">
                        <Wand2 size={10} /> auto-filled
                      </span>
                    )}
                  </Label>
                  <Input
                    id="res-url"
                    type="url"
                    value={newUrl}
                    onChange={(e) => setNewUrl(e.target.value)}
                    onBlur={handleUrlBlur}
                    required
                    data-testid="resource-url-input"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="res-desc">Description (optional)</Label>
                  <Textarea
                    id="res-desc"
                    value={newDesc}
                    onChange={(e) => setNewDesc(e.target.value)}
                    rows={2}
                    data-testid="resource-desc-input"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label>Format</Label>
                    <Select
                      value={newFormat}
                      onValueChange={(v) =>
                        setNewFormat(v as ResourceInputFormat)
                      }
                    >
                      <SelectTrigger data-testid="resource-format-select">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Object.values(ResourceInputFormat).map((f) => (
                          <SelectItem key={f} value={f} className="capitalize">
                            {f}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="res-subject">Subject</Label>
                    <Input
                      id="res-subject"
                      value={newSubject}
                      onChange={(e) => setNewSubject(e.target.value)}
                      required
                      data-testid="resource-subject-input"
                    />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="res-grade">Grade Level</Label>
                  <Input
                    id="res-grade"
                    value={newGrade}
                    onChange={(e) => setNewGrade(e.target.value)}
                    required
                    data-testid="resource-grade-input"
                  />
                </div>
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setDialogOpen(false);
                      resetForm();
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createResource.isPending}
                    data-testid="submit-resource-confirm"
                  >
                    {createResource.isPending ? "Submitting…" : "Submit"}
                  </Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        ) : (
          <Button variant="outline" asChild data-testid="sign-in-to-submit">
            <Link href="/auth/login">
              <LogIn size={15} className="mr-1.5" /> Sign in
            </Link>
          </Button>
        )}
      </div>

      {/* Search bar */}
      <form onSubmit={handleSearchSubmit} className="space-y-2">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search
              size={16}
              className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            />
            <Input
              ref={inputRef}
              className="pl-9 pr-9 h-11 text-base"
              placeholder={
                'Search anything — "photosynthesis", "MIT calculus", "Python for beginners"…'
              }
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              data-testid="search-input"
            />
            {inputValue && (
              <button
                type="button"
                onClick={() => {
                  setInputValue("");
                  setActiveQuery("");
                }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                <X size={15} />
              </button>
            )}
          </div>
          <Button
            type="submit"
            size="lg"
            className="shrink-0"
            disabled={!inputValue.trim()}
          >
            <Search size={15} className="mr-1.5" /> Search
          </Button>
        </div>
        <div className="flex flex-wrap gap-2">
          <Select
            value={resultTypeFilter}
            onValueChange={(value) =>
              setResultTypeFilter(value as DiscoverResourcesResultType)
            }
          >
            <SelectTrigger
              className="w-44 h-8 text-xs"
              data-testid="source-filter"
            >
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value={DiscoverResourcesResultType.content}>
                Source: specific content
              </SelectItem>
              <SelectItem value={DiscoverResourcesResultType.source}>
                Source: websites & channels
              </SelectItem>
            </SelectContent>
          </Select>
          <Select
            value={searchLanguage}
            onValueChange={(value) =>
              setSearchLanguage(value as SearchLanguage)
            }
          >
            <SelectTrigger
              className="w-36 h-8 text-xs"
              data-testid="search-language-filter"
            >
              <SelectValue placeholder="Language" />
            </SelectTrigger>
            <SelectContent>
              {SEARCH_LANGUAGE_OPTIONS.map((language) => (
                <SelectItem key={language.code} value={language.code}>
                  {language.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {!isSourceMode && (
            <>
              <Select
                value={formatFilter || "all"}
                onValueChange={(v) => setFormatFilter(v === "all" ? "" : v)}
              >
                <SelectTrigger
                  className="w-36 h-8 text-xs"
                  data-testid="format-filter"
                >
                  <SelectValue placeholder="All formats" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All formats</SelectItem>
                  {FORMAT_OPTIONS.map((f) => (
                    <SelectItem key={f} value={f} className="capitalize">
                      {f}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Input
                className="w-36 h-8 text-xs"
                placeholder="Subject…"
                value={subjectFilter}
                onChange={(e) => setSubjectFilter(e.target.value)}
                data-testid="subject-filter"
              />
              <Select
                value={gradeLevelFilter || "all"}
                onValueChange={(v) => setGradeLevelFilter(v === "all" ? "" : v)}
              >
                <SelectTrigger
                  className="w-36 h-8 text-xs"
                  data-testid="grade-filter"
                >
                  <SelectValue placeholder="All grades" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All grades</SelectItem>
                  {["K–5", "6–8", "9–12", "College", "Adult", "All Ages"].map(
                    (g) => (
                      <SelectItem key={g} value={g}>
                        {g}
                      </SelectItem>
                    ),
                  )}
                </SelectContent>
              </Select>
              <Select
                value={minRatingFilter === "" ? "any" : String(minRatingFilter)}
                onValueChange={(v) =>
                  setMinRatingFilter(v === "any" ? "" : Number(v))
                }
              >
                <SelectTrigger
                  className="w-36 h-8 text-xs"
                  data-testid="rating-filter"
                >
                  <SelectValue placeholder="Any rating" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any">Any rating</SelectItem>
                  {[1, 2, 3, 4, 5].map((n) => (
                    <SelectItem key={n} value={String(n)}>
                      {"★".repeat(n)} & up
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Select
                value={sortByFilter || "newest"}
                onValueChange={(v) =>
                  setSortByFilter(
                    v === "newest" ? "" : (v as ListResourcesSortBy),
                  )
                }
              >
                <SelectTrigger
                  className="w-36 h-8 text-xs"
                  data-testid="sort-filter"
                >
                  <SelectValue placeholder="Newest first" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest first</SelectItem>
                  <SelectItem value={ListResourcesSortBy.top_rated}>
                    Top rated
                  </SelectItem>
                  <SelectItem value={ListResourcesSortBy.most_reviewed}>
                    Most reviewed
                  </SelectItem>
                </SelectContent>
              </Select>
            </>
          )}
        </div>
      </form>

      {isLoggedIn && searchHistory.length > 0 && (
        <section aria-label="Recent searches" className="space-y-2">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Recent searches
          </p>
          <div className="flex flex-wrap gap-2">
            {searchHistory.map((item) => (
              <span
                key={item.query}
                className="inline-flex items-center rounded-full border bg-card"
              >
                <button
                  type="button"
                  className="px-3 py-1.5 text-sm hover:text-primary"
                  onClick={() => {
                    setInputValue(item.query);
                    setActiveQuery(item.query);
                  }}
                >
                  {item.query}
                </button>
                <button
                  type="button"
                  className="border-l px-2 py-1.5 text-muted-foreground hover:text-destructive"
                  aria-label={`Delete ${item.query} from search history`}
                  onClick={() =>
                    me?.id &&
                    setSearchHistory(deleteSearchHistory(me.id, item.query))
                  }
                >
                  <X size={13} />
                </button>
              </span>
            ))}
          </div>
        </section>
      )}

      {/* ── AUTOMATIC INTERNET SOURCE RECOMMENDATION ─────────── */}
      {!isSearching && (
        <section id="recommended-source" className="scroll-mt-16">
          <h2 className="mb-4 flex items-center gap-1.5 text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            <Globe size={14} /> Recommended internet source
          </h2>
          <p className="mb-4 text-sm text-muted-foreground">
            Automatically searched from {isLoggedIn ? "your selected interests and active learning goals" : "high-quality educational sources"}. Saved library sources are excluded.
          </p>
          {personalisedSourcesLoading ? (
            <CardSkeletons count={1} />
          ) : !(personalisedSources ?? []).some((resource) => !hiddenSourceUrls.includes(resource.url) && !savedLibraryUrls.has(resource.url)) ? (
            <div className="rounded-lg border py-10 text-center text-muted-foreground">
              <Globe size={32} className="mx-auto mb-3 opacity-30" />
              <p className="font-medium text-foreground">No new source found</p>
              <p className="mt-1 text-sm">Try adding interests or an active learning goal.</p>
            </div>
          ) : (
            <div className="max-w-xl">
              {(personalisedSources ?? [])
                .filter((resource) => !hiddenSourceUrls.includes(resource.url) && !savedLibraryUrls.has(resource.url))
                .slice(0, 1)
                .map((resource) => (
                  <SourceCard key={resource.url} resource={resource} onSave={handleSaveSource} saving={addingUrl === resource.url} />
                ))}
            </div>
          )}
          <div className="mt-4 space-y-1.5">
            <Button
              variant="outline"
              size="sm"
              disabled={personalisedSourcesLoading || (!isAdmin && sourceRefreshes >= DAILY_SOURCE_RECOMMENDATION_LIMIT)}
              onClick={() => recommendAnotherSource(personalisedSources ?? [])}
              data-testid="personalised-recommend-another-source"
            >
              <RefreshCw size={12} className="mr-1.5" /> Recommend another source
            </Button>
            <p className="text-xs text-muted-foreground">
              {isAdmin ? (
                "Unlimited additional recommendations for admins"
              ) : (
                <>{Math.max(DAILY_SOURCE_RECOMMENDATION_LIMIT - sourceRefreshes, 0)} of {DAILY_SOURCE_RECOMMENDATION_LIMIT} additional recommendations remaining today</>
              )}
            </p>
          </div>
        </section>
      )}


      {/* ── SEARCH RESULTS ────────────────────────────────────────────── */}
      {isSearching && (
        <>
          {/* Library search results */}
          {!isSourceMode && (
            <section>
              <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-4 flex items-center gap-1.5">
                <BookOpen size={14} /> Library — "{activeQuery}"
              </h2>
              {libraryLoading ? (
                <CardSkeletons count={3} />
              ) : !libraryResults || libraryResults.length === 0 ? (
                <p className="text-sm text-muted-foreground py-2">
                  No library results for "{activeQuery}".
                </p>
              ) : (
                <>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {libraryResults.map((r) => (
                      <LibraryCard
                        key={r.id}
                        resource={r}
                        onClick={() => setLocation(`/resources/${r.id}`)}
                        onRemove={
                          me ? () => handleRemoveCard(r.id, r.title) : undefined
                        }
                        onAssign={
                          isTeacher
                            ? () =>
                                setAssignTarget({ id: r.id, title: r.title })
                            : undefined
                        }
                      />
                    ))}
                  </div>
                  {libraryResults.length >= libraryLimit && (
                    <div className="mt-4 text-center">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setLibraryLimit((n) => n + 12)}
                      >
                        Show more results
                      </Button>
                    </div>
                  )}
                </>
              )}
            </section>
          )}

          {/* Web results */}
          <section>
            <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wide mb-4 flex items-center gap-1.5">
              <Sparkles size={14} />{" "}
              {resultTypeFilter === DiscoverResourcesResultType.source
                ? "Sources & channels"
                : "From the Web"}{" "}
              — "{activeQuery}"
            </h2>

            {webLoading && (
              <div className="space-y-3">
                <p className="text-xs text-muted-foreground flex items-center gap-1.5">
                  <Loader2 size={12} className="animate-spin" /> Searching the
                  entire web…
                </p>
                <CardSkeletons />
              </div>
            )}

            {webError && !webLoading && webRateLimited && (
              <div className="py-6 text-center">
                <p className="text-sm text-amber-600 font-medium">
                  Search limit reached — you can run up to 5 AI web searches per
                  minute.
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Try again in {webRateLimitRetryAfter} second
                  {webRateLimitRetryAfter !== 1 ? "s" : ""}.
                </p>
              </div>
            )}

            {webError && !webLoading && !webRateLimited && (
              <div className="py-6 text-center">
                <p className="text-sm text-destructive font-medium">
                  Web search failed — please try again.
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-3"
                  onClick={() => setActiveQuery(activeQuery)}
                >
                  Retry
                </Button>
              </div>
            )}

            {!webError && allWebResults.length > 0 && (
              <>
                {!isSourceMode && !isLoggedIn && (
                  <p className="text-xs text-muted-foreground mb-3">
                    <Link href="/auth/login" className="text-primary underline">
                      Sign in
                    </Link>{" "}
                    to save web results to your library.
                  </p>
                )}
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {(isSourceMode
                    ? allWebResults
                        .filter(
                          (resource) =>
                            !hiddenSourceUrls.includes(resource.url) &&
                            !savedLibraryUrls.has(resource.url),
                        )
                        .slice(0, 1)
                    : allWebResults
                  ).map((r, i) =>
                    isSourceMode ? (
                      <SourceCard
                        key={r.url}
                        resource={r}
                        onSave={handleSaveSource}
                        saving={addingUrl === r.url}
                      />
                    ) : (
                      <WebCard
                        key={i}
                        resource={r}
                        onAdd={handleAddWeb}
                        adding={addingUrl === r.url}
                      />
                    ),
                  )}
                </div>
                <div className="mt-4 text-center">
                  {isSourceMode ? (
                    <div className="space-y-1.5">
                      <Button
                        variant="outline"
                        size="sm"
                        disabled={
                          (!isAdmin && sourceRefreshes >= DAILY_SOURCE_RECOMMENDATION_LIMIT) ||
                          webLoading
                        }
                        onClick={() => recommendAnotherSource()}
                        data-testid="recommend-another-source"
                      >
                        <RefreshCw size={12} className="mr-1.5" /> Recommend
                        another source
                      </Button>
                      <p className="text-xs text-muted-foreground">
                        {isAdmin ? (
                          "Unlimited additional recommendations for admins"
                        ) : (
                          <>
                            {Math.max(DAILY_SOURCE_RECOMMENDATION_LIMIT - sourceRefreshes, 0)} of {DAILY_SOURCE_RECOMMENDATION_LIMIT} additional recommendations remaining today
                          </>
                        )}
                      </p>
                    </div>
                  ) : (
                    <Button
                      variant="outline"
                      size="sm"
                      disabled={webLoading}
                      onClick={() => setWebPage((p) => p + 1)}
                    >
                      {webLoading ? (
                        <>
                          <Loader2 size={12} className="mr-1.5 animate-spin" />{" "}
                          Loading…
                        </>
                      ) : (
                        <>
                          <Sparkles size={12} className="mr-1.5" /> Search more
                          resources
                        </>
                      )}
                    </Button>
                  )}
                </div>
              </>
            )}
          </section>

          <div className="pt-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={clearSearch}
              className="text-muted-foreground"
            >
              <X size={13} className="mr-1.5" /> Clear search — back to library
            </Button>
          </div>
        </>
      )}

      {/* Assign to Class dialog (teacher) */}
      <Dialog
        open={!!assignTarget}
        onOpenChange={(open) => {
          if (!open) {
            setAssignTarget(null);
            setAssignClassId("");
          }
        }}
      >
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Assign to Class</DialogTitle>
            <DialogDescription>
              Add <strong>{assignTarget?.title}</strong> to a class resource
              list for your students.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {!classes || classes.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                You don't have any classes yet.
              </p>
            ) : (
              <Select value={assignClassId} onValueChange={setAssignClassId}>
                <SelectTrigger data-testid="assign-class-select">
                  <SelectValue placeholder="Select a class…" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map((c) => (
                    <SelectItem key={c.id} value={String(c.id)}>
                      {c.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
            <DialogFooter>
              <Button
                variant="outline"
                onClick={() => {
                  setAssignTarget(null);
                  setAssignClassId("");
                }}
              >
                Cancel
              </Button>
              <Button
                onClick={handleAssign}
                disabled={!assignClassId || assignResource.isPending}
                data-testid="assign-to-class-confirm"
              >
                {assignResource.isPending ? "Assigning…" : "Assign"}
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
